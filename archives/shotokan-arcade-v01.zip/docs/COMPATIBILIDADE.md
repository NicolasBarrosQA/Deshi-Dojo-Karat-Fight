# Compatibilidade, evidências e avaliação visual

Validação em 10/10/2026, Linux x86-64 no ambiente cloud. Não tivemos acesso ao Raspberry Pi, ao cartão ou ao notebook pessoal.

## Alvo de 2019

A release oficial Recalbox `6.1-Dragonblaze` (`8ffdef58cf5a555451581c6cf7a8bee33b0ed07c`) fixa TIC-80 `b3e158c15997beba019aa02cfad3c7d70caca84e`, de 03/09/2019, identificado como **0.80.0-dev**. `configs/recalbox-rpi3_defconfig` habilita `BR2_PACKAGE_LIBRETRO_TIC80=y`; o sistema aceita `.tic` em `/recalbox/share/roms/tic80/`. Isso comprova o suporte na distribuição oficial, não o estado do cartão do gabinete.

Fontes primárias: [pacote Recalbox](https://gitlab.com/recalbox/recalbox/-/blob/8ffdef58cf5a555451581c6cf7a8bee33b0ed07c/package/libretro-tic80/libretro-tic80.mk), [configuração Pi 3](https://gitlab.com/recalbox/recalbox/-/blob/8ffdef58cf5a555451581c6cf7a8bee33b0ed07c/configs/recalbox-rpi3_defconfig), [memória/versão TIC](https://github.com/nesbox/TIC-80/blob/b3e158c15997beba019aa02cfad3c7d70caca84e/src/tic.h), [renderizador/loader](https://github.com/nesbox/TIC-80/blob/b3e158c15997beba019aa02cfad3c7d70caca84e/src/tic.c), [entrada libretro](https://github.com/nesbox/TIC-80/blob/b3e158c15997beba019aa02cfad3c7d70caca84e/src/system/libretro/tic80_libretro.c). A declaração do pacote está preservada offline em `prototypes/tic80/docs/recalbox61-tic80.mk.txt`.

APIs usadas nesta versão: `TIC`, `btn`, `spr`, `memcpy`, `rect`, `rectb`, `line`, `print`, além das funções padrão Lua 5.3. Sem `BOOT`, `vbank`, bancos adicionais, código comprimido, arquivos externos, persistência ou rede nas partidas. Os sprites/tiles compartilham 512 tiles de 8×8 em um banco. O cenário usa o começo da área de mapa como cache de framebuffer: `memcpy(0,0x8000,16320)`. Essa área não pode simultaneamente conter um tilemap convencional sem mudar a estratégia. O endereço e a cópia foram exercitados no núcleo histórico.

## Recursos medidos do cartucho

| Recurso | Uso nesta versão | Consequência |
|---|---:|---|
| Tela lógica | 240×136 | Dois personagens de aproximadamente 48–64 px de altura cabem; detalhes de rosto ficam reduzidos a poucos pixels |
| Paleta | 16 cores compartilhadas | Tons de gi, pele, cabelo e cenário disputam a mesma paleta; sem paleta independente por personagem |
| Arte de personagens | 381 / 512 tiles; 12.192 bytes | 131 tiles livres, 4.192 bytes; deduplicação permite 15 poses para cada um dos dois personagens |
| Cenário cacheado | 16.320 bytes / área de mapa de 32.640 bytes | Um dojo estático detalhado sem consumir os tiles dos lutadores |
| Código Lua banco 0 | 19.853 / 65.535 bytes | Inclui a tabela de poses; margem de código suficiente para esta etapa |
| Cartucho completo | 48.433 bytes | Inclui código, cenário, sprites e paleta; não representa consumo total de RAM do processo |
| Memória do interpretador/processo | Não medida no ARM | O limite de 1 GB precisa ser avaliado junto com Recalbox/RetroArch, não só pelo tamanho do cartucho |

Sprites são mosaicos de tiles não vazios. Fundo é uma cópia de 16 KiB por tick. Não há shaders, transparência parcial, vídeo, leitura de disco ou dependência de aceleração OpenGL no código do jogo. RetroArch ainda precisa apresentar a imagem via o driver do sistema. Essa estrutura é apropriada para investigar o Pi 3, mas o resultado x86 não comprova 60 fps, estabilidade térmica ou consumo no ARM.

## Evidências executadas

| Verificação | Resultado | Alcance da evidência |
|---|---|---|
| 19 testes de combate | Passaram em Lua 5.3.1 | Lógica de seleção, fases, limites, defesa, qualidade, ambos os lados, simultaneidade, timer, resultado, revanche e 6.000 ticks aleatórios; desenho substituído por stubs neste grupo |
| Cartucho entregue | Carregou e renderizou | 11 vistas reais e GIF produzidos com o loader, API Lua, sprite, memória e input históricos |
| Quatro grupos de integração nativa | Passaram | Integridade/chunks, 16 entradas separadas, pontuação simultânea/contato único, vitória, revanche, 3.600 ticks de timeout, empate e retorno à seleção |
| Viewer Tk/Linux | Passou | Janela em Xvfb, 120 frames e captura; não sessão humana no notebook |
| HTML com contexto Chromium offline | Passou | Seleção, sprites, colisão/pontuação P1/P2, teclado, movimento simultâneo, menus e ausência de erros JS/Lua |
| Raster browser/nativo na tela inicial | Idêntico pixel a pixel | Comparação dos 240×136 pixels; não comprova equivalência de timing de todos os frames |
| Raspberry Pi 3/Recalbox instalado | Não testado | Executável ARM, GPIO, monitor, hotkeys, tensão, temperatura, latência e fluidez pendentes |
| Windows/macOS e browsers pessoais | Não testados | HTML autocontido; policies de arquivos locais e teclados podem variar |

O teste de integração acrescenta `pmem` a uma cópia do cartucho **somente em memória** para ler os estados; essa telemetria não integra o `.tic` entregue. As capturas e o viewer usam o `.tic` entregue, sem alteração nem telemetria.

O runtime de desenvolvimento reutiliza `prototypes/tic80/tools/build_runtime.py`. O submódulo histórico `nesbox/3rd-party` ficou indisponível; foram compilados os arquivos originais de loader/core/API Lua/libretro, sem modificá-los, com Lua habilitado e dependências públicas fixadas no `runtime-lock.json` original. Não é uma reprodução integral do binário Recalbox, não inclui os demais interpretadores e não foi compilado/testado para ARM. Veja a investigação completa em `prototypes/tic80/docs/COMPATIBILIDADE.md`. TLS/integridade não foram desativados.

## Qualidade visual observada

As capturas mostram silhuetas humanas com membros preenchidos e articulados, karategi sombreado, golas, faixas, cabelos distintos e pés. Não são retângulos de colisão exibidos como corpos. O chão está definido, o cenário usa perspectiva e os contornos escuros separam o gi claro do fundo. Os golpes distinguem extensão de braço, perna frontal e perna mais alta; impacto usa pose de reação. As telas principais exibem seleção, nomes, tempo, placar e revanche; o diagnóstico é separado.

Há limitações claras: braços e rostos têm poucos pixels, gi dos dois personagens compartilha as mesmas cores e as silhuetas têm base semelhante. Postura/caminhada usam dois frames cada; ataques usam preparação/ativo e recuperação compartilhada, sem muitos intermediários. Isso produz uma leitura retro apresentável, com animação mais curta e rígida que Street Fighter Alpha/KOF. O cenário é estático e o painel ornamental não é caligrafia validada. A precisão biomecânica de quadril, apoio e trajetória exige revisão presencial de um instrutor. Defesa recuando é uma convenção de jogo, não uma modelagem completa da guarda Shotokan.

Para mais fluidez, a próxima melhoria apropriada é acrescentar intermediários e aprimorar silhuetas, com reutilização de partes e orçamento medido de tiles. A paleta/resolução do TIC-80 não permite reproduzir integralmente o detalhamento das referências. A capacidade atual suporta esta direção retro e não demonstra uma inviabilidade que justifique migrar agora. O motor permanece TIC-80. Se a meta passar a exigir sprites muito maiores, centenas de frames ou paletas independentes, será necessário reavaliar antes de aumentar o elenco.

## Combate ajustável

Cada golpe define preparação, duração ativa, recuperação, avanço, pontos, poses e caixa de contato. Só a pose ativa pode acertar; alcance e região vertical refletem a técnica. Um evento registra técnica, atacante/alvo, distância, qualidade aproximada, zona chudan e resultado. `G.judge` é a fronteira da política de pontuação. No protótipo, qualidade abaixo de 40 não pontua; golpes de mão valem 1 e pés 2. Não há redução de vida.

Os mesmos dados podem posteriormente alimentar árbitro, alvo de precisão ou outras regras. A caixa corporal é simplificada e fixa; posição relativa não mede controle, zanshin ou execução correta. Não apresentar esta regra como regulamento oficial Shotokan. Personagens têm os mesmos atributos nesta versão, e o browser não faz arbitragem diferente do cartucho.

## Capturas reais

- [Combate](kumite-4x.png), [movimento](movement-4x.png), [oi-zuki](oi-zuki-4x.png), [gyaku-zuki](gyaku-zuki-4x.png), [mae-geri](mae-geri-4x.png), [mawashi-geri](mawashi-geri-4x.png).
- [Título](title-4x.png), [seleção](selection-4x.png), [resultado](result-4x.png), [revanche](rematch-4x.png), [diagnóstico](diagnostic-4x.png).
- [GIF da execução](kumite-execution.gif): postura, aproximação, soco, reação, retomada e chute; frames reais amostrados a cada três ticks, sem interpolação.

Os PNGs originais têm 256×144 com a borda libretro; versões ampliadas são 960×544 com nearest-neighbor. A área do jogo permanece 240×136. Nenhuma captura é do fliperama físico.
