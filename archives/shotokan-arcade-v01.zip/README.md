# Deshi Dojo Karate Fight — Shotokan Arcade

Primeira versão com arte original, dois karatecas e combate por pontuação. Esta pasta é independente: o IKEMEN e `prototypes/tic80/` continuam preservados.

## Jogar agora no notebook

1. Extraia `dist/deshi-dojo-arcade.zip`.
2. Abra `deshi-dojo-arcade.html` em um navegador desktop com JavaScript habilitado.
3. Clique em **Escolher personagens**. Cada jogador escolhe com esquerda/direita e confirma com seu botão A. Ambos precisam confirmar.

O HTML contém o interpretador Lua, código e arte; não precisa de servidor, instalação, cadastro ou Internet. A versão browser usa o mesmo Lua e assets do `.tic`, com um adaptador Canvas. Não é o núcleo libretro nem um teste de desempenho do Pi. Não há suporte a controle USB no adaptador browser nesta etapa. Navegadores corporativos podem bloquear arquivos locais; nesse caso use o cartucho em um TIC-80 desktop ou o viewer Linux abaixo.

O ZIP também inclui o cartucho, `game.lua` com o código Lua completo, licenças, relatório e capturas em `docs/`. Os caminhos `dist/`, `src/` e comandos de desenvolvimento abaixo referem-se ao repositório completo; no ZIP os arquivos jogáveis ficam diretamente na pasta extraída.

| Ação | Jogador 1 | Jogador 2 | TIC-80 |
|---|---|---|---|
| Direções | Setas | I / K / J / L | Cima / baixo / esquerda / direita |
| Oi-zuki / confirmar | Z | F | A |
| Gyaku-zuki / cancelar seleção | X | G | B |
| Mae-geri | A | R | X |
| Mawashi-geri | S | T | Y |
| Defender | Recuar | Recuar | Direção contrária ao adversário |
| Diagnóstico / voltar ao título | Z + X por 1 segundo | — | P1 A + B por 60 ticks |

Clique no jogo para focar o teclado. Só esquerda/direita movimentam no combate; cima/baixo são exibidos no diagnóstico. Não há salto/agachamento. Nas telas de resultado, esquerda/direita alternam **Revanche** e **Seleção**, e A confirma. O diagnóstico também tem botão próprio no HTML.

## O que há nesta versão

- REN e AKI: karategi branco, faixas e cabelos distintos, 15 poses por personagem, contornos, sombras, dobras e pés descalços. A seleção permite trocar os personagens e fazer confronto espelhado.
- Dojo com tatame em perspectiva, madeira, shoji, lanternas, bonsai e um painel ornamental original. O painel não pretende reproduzir uma caligrafia japonesa validada.
- Postura, caminhada, guarda, reação, recuperação e quatro técnicas com preparação e execução distintas.
- Separação dos corpos, limites da arena, defesa, uma colisão por execução, breve congelamento no contato e reinício da distância após ponto.
- Seleção independente, nomes, cronômetro de 60 segundos ativos, placar, vitória, empate e revanche. Primeiro a atingir pelo menos 5 pontos vence; dois pontos podem ultrapassar o limite.
- Socos valem 1, chutes 2; contatos fora do alcance ou defendidos não pontuam. `G.judge(event, move)` permite trocar essa política sem reescrever animação/colisão. Distância e qualidade são aproximações em pixels, não avaliação oficial de kumite.

Não há música, efeitos sonoros, IA, personagens reais ou sprites definitivos de alunos. Oi-zuki dá um pequeno avanço; gyaku-zuki gira a postura; mae-geri estende a perna à frente; mawashi-geri usa preparação e extensão mais altas. O arco tridimensional de mawashi e a rotação do quadril estão simplificados em duas poses de ataque: a técnica deve passar por revisão de um instrutor.

## Cartucho e execução nativa

O cartucho é `dist/shotokan-arcade.tic`. Em um TIC-80 desktop já instalado, carregue-o pelo comando `load shotokan-arcade.tic` no console, seguido de `run`, ou abra o arquivo pelo programa. Essa rota depende da versão/plataforma instalada e não foi testada em Windows/macOS. Configure os dois jogadores no programa; não presuma que ele usa as mesmas teclas do HTML.

Para o viewer Linux validado no ambiente de desenvolvimento, a partir da raiz do repositório:

```bash
# Preparação, precisa de Internet somente na primeira vez:
python3 prototypes/tic80/tools/build_runtime.py
# Depois da preparação, execução inteiramente offline (Python 3 + Tk):
python3 games/shotokan-arcade/tools/play_notebook.py
```

O viewer reutiliza o host libretro do protótipo original sem alterar seus arquivos. O `.so` preparado é x86-64 para desenvolvimento; não o copie ao Raspberry Pi.

## Desenvolvimento e verificação

`src/game.lua` contém combate e telas; `src/art.lua` contém os índices de poses. `assets/` contém sprites PNG, atlas e dados binários. `tools/draw_art.py` é a fonte autoral da arte. `dist/game.lua` reúne arte e jogo para o cartucho/browser.

Na raiz do repositório:

```bash
python3 games/shotokan-arcade/tools/build.py
.cache/tic80-legacy/lua53 games/shotokan-arcade/tests/combat.lua games/shotokan-arcade/dist/game.lua
python3 games/shotokan-arcade/tests/native_smoke.py
```

Esses comandos usam Python padrão e o runtime preparado. Para regenerar arte e capturas, instale Pillow no ambiente de desenvolvimento e execute `tools/draw_art.py` e `tests/native_capture.py` desta pasta. O gerador de arte também lê a fonte histórica já preparada para obter a fonte bitmap MIT do TIC-80. As dependências de geração não entram no jogo.

Para regenerar o HTML: `python3 games/shotokan-arcade/tools/prepare_browser.py` verifica e prepara Fengari 0.1.4; depois `python3 games/shotokan-arcade/tools/build_browser.py` embute tudo e gera o ZIP. A primeira preparação exige rede, a compilação seguinte não. `tests/browser.cjs` usa Playwright e Chromium somente para desenvolvimento. O caminho de Chromium no teste corresponde ao ambiente cloud validado.

## Futuro teste no Recalbox, sem substituir jogos

Este trabalho não acessou nem alterou o fliperama. Antes de gravar no cartão, verificar a alimentação (houve avisos de baixa tensão), fazer backup verificável do microSD e identificar a versão realmente instalada do núcleo e o espaço disponível.

Com isso resolvido e acesso ao cartão/share disponível, adicionar somente uma cópia de `shotokan-arcade.tic` em `/recalbox/share/roms/tic80/`, pelo método de transferência suportado pelo equipamento. Atualizar a lista de jogos pelo EmulationStation e executar pelo núcleo TIC-80 existente. Não atualizar Recalbox, trocar drivers GPIO/núcleos nem substituir ROMs ou configurações.

Abrir primeiro o diagnóstico. Verificar separadamente direções e quatro ações dos dois joysticks, inclusive combinações simultâneas. No núcleo histórico, A/B/X/Y do TIC correspondem a **B/A/Y/X do RetroPad**; a posição física dos botões GPIO ainda é desconhecida. Conferir a hotkey existente de saída antes de uma partida. Depois medir fluidez, latência, temperatura e eventuais avisos de tensão por 10–15 minutos e conferir os jogos antigos. Os dois botões físicos adicionais não são exigidos pelo jogo.

## Evidências e limites

Veja [compatibilidade e avaliação visual](docs/COMPATIBILIDADE.md), a [captura de combate](docs/kumite-4x.png), [resultado](docs/result-4x.png) e a [sequência animada real](docs/kumite-execution.gif). São frames do cartucho entregue no núcleo histórico compilado para x86-64, ampliados sem suavização; não imagens conceituais.

**ARM, desempenho no Pi 3, GPIO, notebook pessoal e instalação física continuam pendentes.** Arte/código originais sob MIT. O HTML inclui Fengari MIT e a fonte bitmap histórica TIC-80 MIT; os avisos acompanham o ZIP. Nenhum sprite de Street Fighter, KOF, MUGEN ou IKEMEN foi utilizado aqui.
