// Uses the available development browser only; the delivered game has no dependencies.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'dist/deshi-dojo-arcade.html'),'utf8');
(async()=>{let browser;try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'],timeout:10000});
 const context=await browser.newContext({offline:true,viewport:{width:1100,height:1000}});
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('about:blank?selftest=1');
 await page.setContent(html,{waitUntil:'domcontentloaded',timeout:10000});
 const status=await page.locator('#status').innerText();console.log(status);
 if(await page.locator('body').getAttribute('data-test')!=='passed')throw Error(status);
 await page.screenshot({path:path.join(root,'docs/browser-contact.png')});
 await page.goto('about:blank?capture=1');await page.setContent(html,{waitUntil:'domcontentloaded'});
 const canvas=await page.evaluate(()=>document.getElementById('game').toDataURL());
 fs.writeFileSync(path.join(root,'docs/browser-title-native-resolution.png'),Buffer.from(canvas.split(',')[1],'base64'));
 await page.goto('about:blank');await page.setContent(html,{waitUntil:'domcontentloaded'});
 await page.locator('#play').click();await page.keyboard.press('z',{delay:45});await page.keyboard.press('f',{delay:45});await page.waitForTimeout(40);
 let before=(await page.evaluate(()=>dojoHost.snapshot())).split('|');if(before[0]!=='fight')throw Error('Keyboard confirmation failed');
 await page.keyboard.down('ArrowRight');await page.keyboard.down('j');await page.waitForTimeout(220);await page.keyboard.up('ArrowRight');await page.keyboard.up('j');
 let after=(await page.evaluate(()=>dojoHost.snapshot())).split('|');
 if(!(+after[1]>+before[1]&&+after[2]<+before[2]))throw Error('Independent movement failed');
 await page.locator('#diagnostic').click();await page.waitForTimeout(40);if((await page.evaluate(()=>dojoHost.snapshot())).split('|')[0]!=='diagnostic')throw Error('Diagnostic menu failed');
 await page.locator('#title').click();await page.waitForTimeout(40);if((await page.evaluate(()=>dojoHost.snapshot())).split('|')[0]!=='title')throw Error('Title menu failed');
 if(errors.length)throw Error(errors.join('\n'));
 console.log('PASS browser offline: raster art, selection, 2-player keyboard, collision/scoring, menus and no JS/Lua errors');
 }catch(e){console.error(e.message);process.exitCode=1}finally{if(browser)await browser.close()}})();
