"""Real screenshots/GIF from the delivered .tic through the historical core."""
import sys
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'prototypes/tic80/tools'))
from legacy_core import Core
cart=(HERE/'dist/shotokan-arcade.tic').read_bytes()
def open_core():return Core(ROOT/'.cache/tic80-legacy/tic80_libretro.so',cart)
def step(core,n,keys=(),film=None):
 core.buttons.clear()
 for key in keys:core.key(key,True)
 for i in range(n):
  core.tick()
  if film is not None and i%3==0:
   w,h,rgb=core.frame
   film.append(Image.frombytes('RGB',(w,h),rgb).resize((768,432),Image.Resampling.NEAREST))
def capture(core,name):
 path=HERE/'docs'/f'{name}.png';path.write_bytes(core.png())
 Image.open(path).resize((960,544),Image.Resampling.NEAREST).save(HERE/'docs'/f'{name}-4x.png')
def start(core):
 step(core,1,(4,));step(core,1);step(core,1,(4,12));step(core,1)
core=open_core()
step(core,1);capture(core,'title')
step(core,1,(4,));step(core,1);capture(core,'selection')
step(core,1,(4,12));step(core,1);capture(core,'kumite')
step(core,45,(3,10));capture(core,'movement')
step(core,60,(4,5));step(core,1);capture(core,'diagnostic');core.close()
for index,name in enumerate(['oi-zuki','gyaku-zuki','mae-geri','mawashi-geri']):
 core=open_core();step(core,1);start(core);step(core,52,(3,10));step(core,1,(4+index,));step(core,[9,7,13,16][index]);capture(core,name);core.close()
core=open_core();step(core,1);start(core)
for _ in range(3):
 step(core,52,(3,10));step(core,1,(6,));step(core,13);step(core,60)
capture(core,'result')
step(core,1,(4,));step(core,1);capture(core,'rematch');core.close()
core=open_core();step(core,1);start(core);film=[]
for n,keys in [(30,()),(52,(3,10)),(1,(4,)),(9,()),(65,()),(50,(3,10)),(1,(15,)),(16,()),(65,())]:step(core,n,keys,film)
film[0].save(HERE/'docs/kumite-execution.gif',save_all=True,append_images=film[1:],duration=50,loop=0,optimize=True)
core.close()
print('PASS delivered cartridge: 11 native views and actual idle/walk/punch/kick execution GIF')
