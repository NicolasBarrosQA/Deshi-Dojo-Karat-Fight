-- title: Deshi Dojo Karate Fight - Shotokan Arcade
-- author: Deshi Dojo contributors
-- script: lua
-- license: MIT
-- Original raster sprite art, single palette and 2019 TIC-80 APIs.
G={mode="title",frame=0,selections={1,2},ready={false,false},hold=0,
   target=5,duration=3600,clock=3600,pause=0,freeze=0,event=nil,
   result=nil,inputs={{held={},previous={}},{held={},previous={}}}}
G.characters={{id="ren",name="REN",style="AVANCO",color=12},
              {id="aki",name="AKI",style="DISTANCIA",color=13}}
local FLOOR=122
G.moves={
 {name="OI-ZUKI",prep="oi0",pose="oi1",start=9,active=5,recovery=17,advance=4,points=1,box={x=14,y=21,w=19,h=9}},
 {name="GYAKU-ZUKI",prep="gyaku0",pose="gyaku1",start=7,active=4,recovery=18,advance=0,points=1,box={x=12,y=25,w=19,h=8}},
 {name="MAE-GERI",prep="mae0",pose="mae1",start=13,active=5,recovery=23,advance=0,points=2,box={x=23,y=36,w=18,h=9}},
 {name="MAWASHI-GERI",prep="mawashi0",pose="mawashi1",start=16,active=6,recovery=25,advance=0,points=2,box={x=23,y=25,w=19,h=12}}
}
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end
local function readInputs()
 for i,c in ipairs(G.inputs) do
  for b=0,7 do c.previous[b]=c.held[b] or false c.held[b]=btn((i-1)*8+b) end
 end
end
local function down(i,b) return G.inputs[i].held[b] end
local function edge(i,b) return down(i,b) and not G.inputs[i].previous[b] end
local function player(i)
 return {id=i,character=G.selections[i],x=i==1 and 58 or 182,face=i==1 and 1 or -1,
         score=0,attack=nil,tick=0,spent=false,guard=false,stun=0,walking=false,pose="idle0"}
end
function G.startFight()
 G.p={player(1),player(2)} G.clock=G.duration G.pause=0 G.freeze=0 G.event=nil G.result=nil G.mode="fight"
 G.hold=0
end
G.p={player(1),player(2)}
function G.select() G.mode="select" G.ready={false,false} G.event=nil end
function G.diagnostic() G.mode="diagnostic" G.p={player(1),player(2)} G.hold=0 end
local function intersects(a,b)
 return a.x<b.x+b.w and b.x<a.x+a.w and a.y<b.y+b.h and b.y<a.y+a.h
end
function G.hurt(p) return {x=p.x-8,y=FLOOR-47,w=16,h=46} end
function G.hit(p)
 if not p.attack or p.spent or p.tick<p.attack.start or p.tick>=p.attack.start+p.attack.active then return nil end
 local b=p.attack.box
 return {x=p.face==1 and p.x+b.x or p.x-b.x-b.w,y=FLOOR-64+b.y,w=b.w,h=b.h}
end
-- Replaceable rules: no life bar and no claim of official Shotokan refereeing.
function G.judge(e,move)
 if e.result~="contact" or e.quality<40 then return 0 end
 return move.points
end
local function contact(a,b)
 local h=G.hit(a)
 if not h or not intersects(h,G.hurt(b)) then return nil end
 local distance=math.abs(a.x-b.x)
 local ideal=a.attack.box.x+a.attack.box.w-2
 local quality=clamp(math.floor(100-math.abs(distance-ideal)*3),0,100)
 local e={source=a.id,target=b.id,technique=a.attack.name,distance=math.floor(distance),
          quality=quality,zone="chudan",result=b.guard and "blocked" or "contact",
          x=(a.x+b.x)/2,y=h.y+h.h/2,frame=G.frame}
 e.points=G.judge(e,a.attack)
 return e
end
local function bound()
 local a,b=G.p[1],G.p[2]
 a.x=clamp(a.x,20,220) b.x=clamp(b.x,20,220)
 if b.x-a.x<24 then local middle=clamp((a.x+b.x)/2,32,208) a.x=middle-12 b.x=middle+12 end
end
local function finish(reason)
 local a,b=G.p[1].score,G.p[2].score
 G.result={winner=a==b and 0 or (a>b and 1 or 2),reason=reason}
 G.mode="result" G.rematch=1
end
local function combat()
 if G.freeze>0 then G.freeze=G.freeze-1 return end
 if G.pause>0 then
  G.pause=G.pause-1
  for _,p in ipairs(G.p) do
   if p.stun>0 then p.stun=p.stun-1 p.pose="react"
   elseif p.attack then
    p.tick=p.tick+1
    local m=p.attack
    p.pose=p.tick<m.start+m.active and m.pose or "recover"
   else p.pose="idle1" end
  end
  if G.pause==0 then
   for i,p in ipairs(G.p) do
    p.x=i==1 and 58 or 182 p.attack=nil p.tick=0 p.stun=0 p.guard=false p.pose="idle0"
   end
  end
  return
 end
 G.clock=math.max(0,G.clock-1)
 for i,p in ipairs(G.p) do
  p.walking=false p.guard=false
  if p.stun>0 then p.stun=p.stun-1 p.pose="react"
  elseif p.attack then
   p.tick=p.tick+1
   local m=p.attack
   if p.tick<m.start then p.pose=m.prep
   elseif p.tick<m.start+m.active then p.pose=m.pose
   elseif p.tick<m.start+m.active+m.recovery then p.pose="recover"
   else p.attack=nil p.pose="idle0" end
  else
   local direction=(down(i,3) and 1 or 0)-(down(i,2) and 1 or 0)
   p.walking=direction~=0 p.guard=direction==-p.face
   p.x=p.x+direction*.85
   p.pose=p.guard and "guard" or (p.walking and (math.floor(G.frame/6)%2==0 and "step0" or "step1") or (math.floor(G.frame/24)%2==0 and "idle0" or "idle1"))
   if not (down(i,4) and down(i,5)) then
    for b=4,7 do
     if edge(i,b) then
      p.attack=G.moves[b-3] p.tick=0 p.spent=false p.guard=false p.pose=p.attack.prep
      p.x=p.x+p.face*p.attack.advance break
     end
    end
   end
  end
 end
 bound()
 -- Snapshot both candidates before applying effects: true simultaneous scoring.
 local a,b=contact(G.p[1],G.p[2]),contact(G.p[2],G.p[1])
 for _,e in ipairs({a or false,b or false}) do
  if e then
   local attacker,target=G.p[e.source],G.p[e.target]
   attacker.spent=true attacker.score=attacker.score+e.points G.event=e
   if e.result=="contact" then target.stun=12 target.pose="react" target.x=target.x-target.face*2 end
   G.freeze=5
   if e.points>0 then G.pause=48 end
  end
 end
 bound()
 if G.p[1].score>=G.target or G.p[2].score>=G.target then finish("PONTUACAO")
 elseif G.clock==0 then finish("TEMPO") end
end
local function background() memcpy(0,0x8000,16320) end
local function text(s,x,y,c,scale)
 return print(s,math.floor(x),math.floor(y),c or 8,true,scale or 1)
end
local function centered(s,y,c,scale)
 scale=scale or 1 text(s,(240-#s*6*scale)/2,y,c,scale)
end
local function sprite(character,pose,x,ground,face)
 local f=face==-1 and 1 or 0
 for _,cell in ipairs(ART[G.characters[character].id][pose]) do
  local sx=face==1 and x-32+cell[1] or x+32-cell[1]-8
  spr(cell[3],math.floor(sx),ground-64+cell[2],0,1,f,0,1,1)
 end
end
local function shadow(x)
 for y=0,3 do line(math.floor(x-14+y*2),FLOOR+1+y,math.floor(x+14-y*2),FLOOR+1+y,11) end
end
local function fighter(p)
 shadow(p.x)
 sprite(p.character,p.pose,p.x,FLOOR,p.face)
end
local function hud()
 rect(0,0,240,25,0) line(0,24,239,24,6)
 text(G.characters[G.p[1].character].name,8,4,8)
 text(G.characters[G.p[2].character].name,208,4,8)
 local seconds=math.ceil(G.clock/60)
 text(string.format("%02d",seconds),108,5,7,2)
 for i,p in ipairs(G.p) do
  for n=1,G.target do
   local x=i==1 and 8+(n-1)*10 or 224-(n-1)*10
   rect(x,14,7,6,p.score>=n and (i==1 and 12 or 13) or 2)
  end
 end
end
local function arena()
 background() hud()
 for _,p in ipairs(G.p) do fighter(p) end
 if G.event and G.frame-G.event.frame<40 then
  local e=G.event
  if G.frame-e.frame<8 then
   local x=math.floor(e.x) local y=math.floor(e.y)
   line(x-3,y,x+3,y,7) line(x,y-3,x,y+3,8)
  end
  if e.points>0 then centered(e.technique.." +"..e.points,31,7) end
 end
 text("KUMITE",8,130,9) text("PRIMEIRO A 5",159,130,9)
end
local function title()
 background()
 centered("DESHI DOJO PRESENTS",8,6)
 sprite(1,"idle0",43,FLOOR,1) sprite(2,"idle1",196,FLOOR,-1)
 rect(47,29,146,58,0) rectb(49,31,142,54,6)
 centered("DESHI DOJO",38,8,2) centered("KARATE FIGHT",57,7)
 line(72,68,167,68,12) line(76,71,163,71,13)
 centered("SHOTOKAN ARCADE",77,9)
 centered("A: JOGAR   B: CONTROLES",101,8)
 centered("DOIS JOGADORES / OFFLINE",129,7)
 if edge(1,4) or edge(2,4) then G.select()
 elseif edge(1,5) then G.diagnostic() end
end
local function selectScreen()
 background()
 rect(0,0,240,24,0) centered("ESCOLHA SEU KARATECA",7,7)
 for i=1,2 do
  if not G.ready[i] then
   if edge(i,2) or edge(i,3) then G.selections[i]=3-G.selections[i] end
   if edge(i,4) then G.ready[i]=true end
  elseif edge(i,5) then G.ready[i]=false end
  local x=i==1 and 61 or 179 local who=G.characters[G.selections[i]]
  text("P"..i,x-6,29,i==1 and 12 or 13)
  text(who.name,x-#who.name*3,42,8)
  shadow(x) sprite(G.selections[i],math.floor(G.frame/24)%2==0 and "idle0" or "idle1",x,FLOOR,i==1 and 1 or -1)
  text(G.ready[i] and "PRONTO" or "<  A  >",x-21,129,G.ready[i] and 7 or 8)
 end
 if G.ready[1] and G.ready[2] then G.startFight() end
end
local function diagnostic()
 background() rect(0,0,240,65,0) centered("DIAGNOSTICO DOS CONTROLES",5,7)
 local labels={"U","D","L","R","A","B","X","Y"}
 for i,p in ipairs(G.p) do
  local x=i==1 and 9 or 130
  text("P"..i,x,20,i==1 and 12 or 13)
  for b=0,7 do
   local bx=x+(b%4)*24 local by=32+math.floor(b/4)*13
   rect(bx,by,20,10,down(i,b) and (i==1 and 12 or 13) or 2) text(labels[b+1],bx+7,by+2,8)
  end
  p.x=clamp(p.x+(down(i,3) and 1 or 0)-(down(i,2) and 1 or 0),20,220)
  p.pose=(down(i,2) or down(i,3)) and "step0" or "idle0"
  fighter(p)
 end
 centered("P1 A+B 1s: VOLTAR",129,7)
end
local function results()
 arena()
 rect(36,30,168,61,0) rectb(38,32,164,57,6)
 local result=G.result
 local name=result.winner==0 and "EMPATE" or G.characters[G.p[result.winner].character].name.." VENCEU"
 centered(name,39,7,2)
 centered(G.p[1].score.."  -  "..G.p[2].score,58,8)
 centered(G.rematch==1 and "> REVANCHE <" or "> SELECAO <",73,8)
 if edge(1,2) or edge(1,3) or edge(2,2) or edge(2,3) then G.rematch=3-G.rematch end
 if edge(1,4) or edge(2,4) then
  if G.rematch==1 then G.startFight() else G.select() end
 end
end
function TIC()
 G.frame=G.frame+1 readInputs()
 G.hold=(down(1,4) and down(1,5)) and G.hold+1 or 0
 if G.hold==60 then
  if G.mode=="diagnostic" then G.mode="title" else G.diagnostic() end
 end
 if G.mode=="title" then title()
 elseif G.mode=="select" then selectScreen()
 elseif G.mode=="fight" then combat() if G.mode=="result" then results() else arena() end
 elseif G.mode=="result" then results()
 elseif G.mode=="diagnostic" then diagnostic() end
end
