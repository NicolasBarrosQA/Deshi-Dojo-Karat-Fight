"""Build a bank-0 2019-compatible cart containing original art and Lua."""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[1]
def chunk(kind,data):return struct.pack('<BHB',kind,len(data),0)+data
code=(ROOT/'src/art.lua').read_bytes()+(ROOT/'src/game.lua').read_bytes()
assert 0<len(code)<65536 and b'\0' not in code
sprites=(ROOT/'assets/tiles.bin').read_bytes()
assert len(sprites)<=16384
# Tiles and sprites form one contiguous set of 512 4-bpp 8x8 tiles.
cart=chunk(12,(ROOT/'assets/palette.bin').read_bytes())+chunk(1,sprites[:8192])+chunk(2,sprites[8192:])+chunk(4,(ROOT/'assets/dojo.bin').read_bytes())+chunk(5,code)
(ROOT/'dist/shotokan-arcade.tic').write_bytes(cart)
(ROOT/'dist/game.lua').write_bytes(code)
(ROOT/'dist/SHA256SUMS.txt').write_text(hashlib.sha256(cart).hexdigest()+'  shotokan-arcade.tic\n')
print('Cart:',len(cart),'bytes; Lua:',len(code),'/65535; art:',len(sprites)//32,'/512 tiles')
