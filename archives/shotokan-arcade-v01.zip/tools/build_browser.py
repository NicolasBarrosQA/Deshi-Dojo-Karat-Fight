"""Offline HTML: same Lua, same palette, tiles, bitmap background and pixel font."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parents[1]
vm=ROOT/'.cache/fengari-web/fengari-web.js'
assert vm.exists(),'Prepare the verified Fengari runtime first.'
lock=json.loads((HERE/'browser/runtime-provenance.json').read_text())
assert hashlib.sha256(vm.read_bytes()).hexdigest()==lock['runtime_sha256'],'Run prepare_browser.py: runtime hash mismatch.'
bridge='''local js=require "js"
local h=js.global.dojoHost
function btn(id) return h:button(id) end
function cls(c) h:clear(c) end
function rect(x,y,w,height,c) h:rect(x,y,w,height,c) end
function rectb(x,y,w,height,c) h:rectb(x,y,w,height,c) end
function line(x1,y1,x2,y2,c) h:line(x1,y1,x2,y2,c) end
function print(text,x,y,c,fixed,scale) h:text(tostring(text),x or 0,y or 0,c or 8,scale or 1) end
function spr(id,x,y,color,scale,flip,rotation,w,height) h:sprite(id,x,y,flip or 0) end
function memcpy(dest,source,size)
 assert(dest==0 and source==0x8000 and size==16320)
 h:background()
end
'''
code=(HERE/'dist/game.lua').read_text()
bridge+='\n'+code+'''
h.update=function() TIC() end
h.snapshot=function()
 return G.mode.."|"..G.p[1].x.."|"..G.p[2].x.."|"..G.p[1].score.."|"..G.p[2].score.."|"..G.clock
end
'''
assets={n:(HERE/'assets'/filename).read_bytes().hex() for n,filename in [('background','dojo.bin'),('tiles','tiles.bin'),('font','font.bin')]}
assets['palette']=json.loads((HERE/'assets/atlas.json').read_text())['palette']
page=(HERE/'browser/template.html').read_text().replace('__VM__',vm.read_text().replace('</script','<\\/script')).replace('__LUA__',json.dumps(bridge).replace('<','\\u003c')).replace('__ASSETS__',json.dumps(assets))
output=HERE/'dist/deshi-dojo-arcade.html'
output.write_text(page)
with zipfile.ZipFile(HERE/'dist/deshi-dojo-arcade.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in [output,HERE/'dist/shotokan-arcade.tic',HERE/'dist/game.lua',HERE/'dist/SHA256SUMS.txt',HERE/'LICENSE',HERE/'browser/FENGARI-WEB-LICENSE.txt',HERE/'docs/TIC80-LICENSE.txt']:
  z.write(path,path.name)
 if (HERE/'README.md').exists():z.write(HERE/'README.md','LEIA-ME.md')
 for path in sorted((HERE/'docs').iterdir()):
  if path.suffix in ('.png','.gif','.md'):
   z.write(path,'docs/'+path.name)
print('Offline HTML:',len(page.encode()),'bytes; browser and cartridge share the same Lua/art')
